#!/bin/sh

# No submitted files will be executable; ensure that this script works
# under those conditions.

#sets dir to directory containing this script
dir=`dirname $0`

#use $dir/ as prefix to access any programs in this dir
#so that this script can be run from any directory.