#!/bin/sh

path=`realpath $0`
dir=`dirname $path`

cd "$dir" || exit

cargo build --release
