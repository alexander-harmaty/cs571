use std::env;
use std::io::{self, BufRead};

fn read() -> Option<Vec<i32>> {
    io::stdin().lock().lines().find_map(|line| {
        line.ok().and_then(|l| {
            let nums = l.trim().split_whitespace()
                .filter_map(|n| n.parse().ok())
                .collect::<Vec<i32>>();
            (!nums.is_empty()).then(|| nums)
        })
    })
}

fn sum_vectors(a: &[i32], b: &[i32]) -> Vec<i32> {
    a.iter().zip(b).map(|(x, y)| x + y).collect()
}

fn print(sum: &[i32]) {
    println!("{} ", sum.iter().map(i32::to_string).collect::<Vec<_>>().join(" "));
    println!();
}

fn main() {
    let args = env::args().skip(1).take(2).map(|arg| arg.parse::<usize>().unwrap_or_default()).collect::<Vec<_>>();
    if args.len() != 2 {
        eprintln!("Correct usage: <executable> N_OPS N_ENTRIES");
        std::process::exit(1);
    }
    let (operations, entries) = (args[0], args[1]);
    for _ in 0..operations {
        let first = read().unwrap_or_default();
        let second = read().unwrap_or_default();
        if first.len() == entries && second.len() == entries {
            print(&sum_vectors(&first, &second));
        } else {
            break;
        }
    }
}
