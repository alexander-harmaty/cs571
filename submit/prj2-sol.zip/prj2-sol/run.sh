#!/bin/sh

path=$(realpath $0)
dir=$(dirname $path)

binary="$dir/target/release/prj2-sol"

"$binary" "$@"
